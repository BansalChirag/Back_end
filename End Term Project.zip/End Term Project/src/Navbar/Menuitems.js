export const Menuitems = [

    {
        title : 'Home',
        url : '/',
        cName : 'nav-links'
    },
    {
        title : 'Book Property',
        url : '/',
        cName : 'nav-links'
    },
    {
        title : 'Post Property',
        url : '/',
        cName : 'nav-links'
    }, 
    {
        title : 'Predict Trends',
        url : '/',
        cName : 'nav-links'
    },
    {
        title : 'Broker Details',
        url : '/',
        cName : 'nav-links'
    }

]