

import property1 from './property1.jfif';
import property2 from './property2.jfif';
import property3 from './property3.jfif';
import property4 from './property4.jfif';
import property5 from './property5.jfif';
import property6 from './property6.jfif';
import property7 from './property7.jfif';
import property8 from './property8.jfif';
import property9 from './property9.jfif';

const product_card=[
    {
        id:1,
        product_name:"Garden Square",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb: property1
        
    },
    {
        id:2,
        product_name:"Bysani Skyway",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb:property2
    },
    {
        id:3,
        product_name:"Prestige Shantiniketan",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb:property3
    },
    {
        id:4,
        product_name:"Brigade Rubix",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb:property4
    },
    {
        id:5,
        product_name:"Shoba Apratments",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb:property5
    },
    {
        id:6,
        product_name:"Purva Riveria",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb:property6
    },
    {
        id:7,
        product_name:"Mini Palais",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb:property7
    },
    {
        id:8,
        product_name:"Adarsh Vista",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb:property8
    },
    {
        id:9,
        product_name:"EcoStay",
        description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis aliquam doloremque esse ea pariatur ut officia nostrum nobis vitae!",
        price:350,
        currency:"/-",
        thumb:property9
    }
]

export default product_card;

