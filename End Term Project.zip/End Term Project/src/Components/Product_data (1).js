import image1 from './image1.jpg';
const product_card=[
    {
        id:1,
        product_name:"property1",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb: image1
        
    },
    {
        id:2,
        product_name:"property2",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb:image1
    },
    {
        id:3,
        product_name:"property3",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb:image1
    },
    {
        id:4,
        product_name:"property4",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb:image1
    },
    {
        id:5,
        product_name:"property5",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb:image1
    },
    {
        id:6,
        product_name:"property6",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb:image1
    },
    {
        id:7,
        product_name:"property7",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb:image1
    },
    {
        id:8,
        product_name:"property8",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb:image1
    },
    {
        id:9,
        product_name:"property9",
        description:"abc abc abc abc",
        price:350,
        currency:"/-",
        thumb:image1
    }
]

export default product_card;
